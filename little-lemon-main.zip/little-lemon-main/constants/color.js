export const colors = {
  YELLOW: '#F4CE14',
  GREEN: '#495E57',
  GRAY: '#EDEFEE',
  ORANGE: '#EE9972',
  TAN: '#FBDABB',
  BLACK: '#333333',
};
