import React from "react";
import Navigation from "./Navigation";

const Naviagtion = () => <Navigation />;

export default Naviagtion;
