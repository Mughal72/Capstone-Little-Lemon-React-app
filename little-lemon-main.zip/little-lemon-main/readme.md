# little-lemon
Please use iPhone 14 simulator if possible as that is the main one I used to test. Of course, any device should work great. 
